select * from goals ; 
select * from matches;
select * from players;
select * from stadium;
select * from teams;

select count(*) as total_teams from teams;

select count(*) as total_teams from teams where country = 'Italy'
select count(*) as total_teams from teams where country = 'Netherlands'
select count(*) as total_teams from teams where country = 'Germany'
select count(*) as total_teams from teams where country = 'Turkey'
select count(*) as total_teams from teams where country = 'Switzerland'
select count(*) as total_teams from teams where country = 'England'
select count(*) as total_teams from teams where country = 'Belgium'
select count(*) as total_teams from teams where country = 'ukraine'
select count(*) as total_teams from teams where country = 'spain'
select count(*) as total_teams from teams where country = 'Portugal'
select count(*) as total_teams from teams where country = 'Austria'
select count(*) as total_teams from teams where country = 'Denmark'
select count(*) as total_teams from teams where country = 'France'
select count(*) as total_teams from teams where country ='Greece'
select count(*) as total_teams from teams where country = 'spain'
select count(*) as total_teams from teams where country = 'Azerbaijan'
select count(*) as total_teams from teams where country = 'Belgium'
select count(*) as total_teams from teams where country = 'Russia'
select count(*) as total_teams from teams where country = 'Poland'
select count(*) as total_teams from teams where country ='Moldova'
select count(*) as total_teams from teams where country ='Sweden'

select AVG(LENGTH(Team_name)) as average_name_length from teams;

select country ,round(avg(capacity)) as average_capacity,count(stadium_id) as total_stadiums from Stadium
group by country
order by total_stadiums DESC;

select sum(goals) from goals;

select count(*) as total_teams from teams where team_name like '%city%'

select team_name || ', ' || country team_country from teams;

select home_team,away_team ,date,attendance from matches
order by attendance desc
limit 1

select home_team,away_team ,date,attendance from matches
where attendance > 1
order by attendance asc
limit 1

select match_id,home_team,away_team,(home_team_score+away_team_score)
as total_score from matches
order by total_score desc
limit 1


select * from players
select * from matches where Stadium = 'Old Trafford'
limit 5;





